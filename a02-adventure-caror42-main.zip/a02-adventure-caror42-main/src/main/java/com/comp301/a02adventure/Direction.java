package com.comp301.a02adventure;

public enum Direction {
  NORTH,
  SOUTH,
  EAST,
  WEST
}
